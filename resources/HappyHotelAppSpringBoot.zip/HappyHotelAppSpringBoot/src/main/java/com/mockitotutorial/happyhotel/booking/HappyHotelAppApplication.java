package com.mockitotutorial.happyhotel.booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HappyHotelAppApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(HappyHotelAppApplication.class, args);
	}

}
